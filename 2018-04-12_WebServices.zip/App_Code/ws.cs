﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class ws : System.Web.Services.WebService {

    #region ################################################################################################################# Wrapper Methods [DON'T MODIFY]
    private Helper helper = new Helper();

    // Database
    private void addParam(string name, object value) { helper.addParam(name, value); }
    private DataSet sqlExecDataSet(string sql) { return helper.sqlExecDataSet(sql); }
    private DataTable sqlExecDataTable(string sql) { return helper.sqlExecDataTable(sql); }
    private DataTable sqlExec(string sql) { return helper.sqlExec(sql); }
    private DataTable sqlExec(string sql, DataTable dt, string udtblParam) { return helper.sqlExec(sql, dt, udtblParam); }
    private DataTable sqlExecQuery(string sql) { return helper.sqlExecQuery(sql); }

    // Serializer
    private void streamJson(string jsonString) { helper.streamJson(jsonString); }
    private void serialize(Object obj) { helper.serialize(obj); }
    private void serializeSingleDataTableRow(DataTable dt) { helper.serializeSingleDataTableRow(dt); }
    private void serializeDataTable(DataTable dt) { helper.serializeDataTable(dt); }
    private void serializeDataSet(DataSet ds) { helper.serializeDataSet(ds); }
    private void serializeXML<T>(T value) { helper.serializeXML(value); }
    private void serializeDictionary(Dictionary<object, object> dic) { helper.serializeDictionary(dic); }
    private void serializeObject(Object obj) { helper.serializeObject(obj); }

	#endregion

	/*
			Once you complete this block of steps you can delete it...

			1) Click the "View" option on the menu bar and select "SQL Server Object Explorer
			2) Double-click the "create_ap.sql" file in the Solution Explorer panel (probably on right-hand of screen)
			3) When the script opens up run it by clicking the little green arrow that is on the tab - not the one on the menu bar
			4) A window will pop up.  Expand "Local" and then select "MSSQLLocalDB" and click the Connect button
			5) In the SQL Server Object Explorer panel click the refresh button
			6) Expand the (localdb)\MSSQLLocalDB and then Databases
			7) You should see the AP database the script created.  If you don't then let me know.

			If all worked then you can delete this comment block if you like.
	 
	 */


}